﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade4
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            int num1, num2;

            if (!int.TryParse(txtNumero1.Text, out num1) || (num1 < 0))
            {

                MessageBox.Show("Numero 1 invalido");
                txtNumero1.Focus();

            }
            else if (!int.TryParse(txtNumero2.Text, out num2) || (num2 < 0))
            {
                MessageBox.Show("Numero 2 invalido");
                txtNumero2.Focus();

            }
            else if(num1 > num2)
            {
                MessageBox.Show("Numero 1 é mairo que numero 2");
                txtNumero1.Focus();
            }
            else
            {
                Random ObjR = new Random();
                int sorteado = ObjR.Next(num1, num2);
                MessageBox.Show(sorteado.ToString());

            }
        }
    }
}
